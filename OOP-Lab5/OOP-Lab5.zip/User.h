#pragma once
#include <vector>
#include "Repository.h"
using namespace Repository;
template<class E>
class User
{
public:
	virtual void add_Car(E& e) = 0;
	virtual void delete_Car(E e) = 0;
	virtual vector<E> search_brand(string brand) = 0;
	virtual vector<E> search_model(string model) = 0;
	virtual vector<E> filter_by_km(double km) = 0;
	virtual vector<E> filter_by_year(int year,int choice) = 0;
	virtual vector<E> sort_by_price() = 0;
};