#pragma once
#include "User.h"
#include "Repository.h"

namespace ClientController {
	class Client :public User<Domain::Car> {
	private:
		Repository::Garage repo;
		vector<Domain::Car> favorites;
	public:
		Client(Repository::Garage& repo);

		void add_Car(Domain::Car& car);
		void delete_Car(Domain::Car car);


		vector<Domain::Car> get_favorites();
		vector<Domain::Car> search_brand(string brand);
		vector<Domain::Car> search_model(string model);
		vector<Domain::Car> sort_by_price();
		vector<Domain::Car> filter_by_km(double km);
		vector<Domain::Car> filter_by_year(int year,int choice);



		

		 
	};
}


