#include "Test.h"
#include <iostream>
int main() {
	TestAll();
	std::cout << "Good Job!";
	return 0;
}